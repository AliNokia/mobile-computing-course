import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AnimalData {
  String animalImage = 'image';
  String animalName = 'name';

  Future<void> setName(String name) async {
    final preferences = await SharedPreferences.getInstance();
    preferences.setString(animalName, name);
  }

  Future<String?> getName() async {
    final preferences = await SharedPreferences.getInstance();
    return preferences.getString(animalName);
  }

  Future<void> setImage(XFile? file) async {
    final preferences = await SharedPreferences.getInstance();
    if (file != null) {
      preferences.setString(animalImage, file!.path);
    } else {}
  }

  Future<XFile?> pickImage() async {
    XFile? file = await ImagePicker().pickImage(source: ImageSource.gallery);
    return file;
  }
}
