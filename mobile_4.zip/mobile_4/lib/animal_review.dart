import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class AnimalReview extends StatefulWidget {
  const AnimalReview({super.key});

  @override
  State<AnimalReview> createState() => _AnimalReviewState();
}

class _AnimalReviewState extends State<AnimalReview> {
  int _counter = 0;
  double _size = 24;
  String _animal = "Parrots";
  String _imagePath = 'image.jpg';
  String _lorem =
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
  void _decrease() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      if (_size >= 2) {
        _size--;
      } else {
        //do nothing
      }
    });
  }

  void _increase() {
    setState(() {
      if (_size <= 40) {
        _size++;
      } else {
        //do nothing
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        // title: Text("""),
      ),
      body: SingleChildScrollView(
        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Invoke "debug painting" (press "p" in the console, choose the
          // "Toggle Debug Paint" action from the Flutter Inspector in Android
          // Studio, or the "Toggle Debug Paint" command in Visual Studio Code)
          // to see the wireframe for each widget.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OutlinedButton(
                  onPressed: _increase,
                  child: const Icon(
                    Icons.add,
                    color: Colors.green,
                  ),
                ),
                OutlinedButton(
                  onPressed: _decrease,
                  child: const Icon(Icons.remove, color: Colors.green),
                ),
              ],
            ),

            Text(
              _animal,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            SizedBox(
              height: 16,
            ),
            Image.asset(_imagePath),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                _lorem,
                style: TextStyle(color: Colors.green, fontSize: _size),
              ),
            ) //to show scrollablility and another style of text,
          ],
        ),
      ),
    );
  }
}
