import 'dart:io';

import 'package:flutter/material.dart';
import 'package:mobile_1/utils/utilities.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MyPet extends StatefulWidget {
  const MyPet({super.key});

  @override
  State<MyPet> createState() => _MyPetState();
}

class _MyPetState extends State<MyPet> {
  String? name;
  String? image;
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    //test
    final SharedPreferences prefs = await _prefs;
    setState(() {
      name = prefs.getString(AnimalData().animalName) ?? "";
      image = prefs.getString(AnimalData().animalImage) ?? "";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(name ?? ""),
          SizedBox(height: 50),
          image != "" ? Image.file(File(image!)) : SizedBox()
        ]),
      ),
    );
  }
}
