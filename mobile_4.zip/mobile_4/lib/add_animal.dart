import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mobile_1/utils/utilities.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddAnimal extends StatefulWidget {
  const AddAnimal({super.key});

  @override
  State<AddAnimal> createState() => _AddAnimalState();
}

class _AddAnimalState extends State<AddAnimal> {
  TextEditingController _controller = TextEditingController();
  final Future<SharedPreferences> sharedPreferences =
      SharedPreferences.getInstance();

  String name = '';
  String image = '';
  XFile? file;

  @override
  void initState() {
    super.initState();
    _initStateAsync();
  }

  Future<void> _initStateAsync() async {
    SharedPreferences prefs = await sharedPreferences;
    setState(() {
      name = prefs.getString('name')!;
      image = prefs.getString('path') ?? '';
    });
  }

  AnimalData animalData = AnimalData();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),
        body: Padding(
          padding: const EdgeInsets.all(23.0),
          child: Column(
            children: [
              Text(
                "Adding pet",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _controller,
                decoration: InputDecoration(
                  hintText: 'Your pets name',
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.green),
                  ),
                ),
              ),
              SizedBox(height: 50),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Add your pets image:"),
                  InkWell(
                    onTap: () async {
                      file = await animalData.pickImage();
                      await animalData.setImage(file);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.green, width: 5),
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      height: 100,
                      width: 100,
                      child: image == ""
                          ? Center(child: Text("Click"))
                          : Image.file(File(image)),
                    ),
                  )
                ],
              ),
              image != "" ? Image.file(File(image!)) : SizedBox(),
              Text(name),
              OutlinedButton(
                onPressed: () async {
                  await animalData.setImage(file);
                  await animalData.setName(_controller.text);
                  SharedPreferences prefs = await sharedPreferences;
                  setState(() {
                    name = prefs.getString('name')!;
                    image = prefs.getString('path') ?? "";
                  });
                  setState(() {});
                  print(image);
                },
                child: Text(
                  'Done',
                  style: TextStyle(color: Colors.green),
                ),
              ),
            ],
          ),
        ));
  }
}
