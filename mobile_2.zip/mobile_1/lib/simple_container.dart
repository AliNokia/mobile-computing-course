import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:mobile_1/animal_review.dart';

class SimpleContainer extends StatelessWidget {
  const SimpleContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (_) => AnimalReview()));
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 8.0),
        padding: EdgeInsets.all(8.0),
        decoration: BoxDecoration(
            color: Colors.green.shade100,
            borderRadius: BorderRadius.all(Radius.circular(8.0))),
        height: 90,
        width: double.infinity,
        child: Row(children: [
          SizedBox(
            width: 16,
          ),
          Container(
            decoration:
                BoxDecoration(shape: BoxShape.circle, color: Colors.green),
            height: 50,
            width: 50,
          ),
          SizedBox(
            width: 16,
          ),
          Text("Animal X"),
        ]),
      ),
    );
  }
}
